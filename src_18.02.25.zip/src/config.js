export const BASE_URL = 'https://norma.nomoreparties.space/api';
